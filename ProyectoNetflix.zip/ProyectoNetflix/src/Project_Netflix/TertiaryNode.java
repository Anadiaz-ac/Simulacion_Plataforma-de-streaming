
package Project_Netflix;

public class TertiaryNode {
    private TertiaryNode left;
    private Object data;
    private TertiaryNode rigth;
    private TertiaryNode center;

    public TertiaryNode(Object data) {
        this.data = data;
    }
    public TertiaryNode getLeft() {
        return left;
    }
    public void setLeft(TertiaryNode left) {
        this.left = left;
    }
    public Object getData() {
        return data;
    }
    public void setData(Object data) {
        this.data = data;
    }
    public TertiaryNode getRigth() {
        return rigth;
    }
    public void setRigth(TertiaryNode rigth) {
        this.rigth = rigth;
    }

    public TertiaryNode getCenter() {
        return center;
    }

    public void setCenter(TertiaryNode center) {
        this.center = center;
    }
    
    
}
