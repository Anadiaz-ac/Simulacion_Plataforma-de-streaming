
package Project_Netflix;


public class Accounts {
    private int code;
    private String headline;
    private String type;
    private String status;
    private String password;
    private Queue profile;
    private int Nprofile;

    public Accounts(int code, String headline, String type, String status, String password, Queue profile, int Nprofile) {
        this.code = code;
        this.headline = headline;
        this.type = type;
        this.status = status;
        this.password = password;
        this.profile = profile;
        this.Nprofile = Nprofile;
    }


    public int getCode() {
        return code;
    }

    public void setCode(int code) {
        this.code = code;
    }

    public String getHeadline() {
        return headline;
    }

    public void setHeadline(String headline) {
        this.headline = headline;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public Queue getProfile() {
        return profile;
    }

    public void setProfile(Queue profile) {
        this.profile = profile;
    }

    public int getNprofile() {
        return Nprofile;
    }

    public void setNprofile(int Nprofile) {
        this.Nprofile = Nprofile;
    }
    
    @Override
    public String toString() {
        return "Code: " + code + "   Headline: " + headline + "   Type: " + type +
                "   Status: " + status + "   Password: " + password + "\nProfile: \n" + c(profile);
    }
 
    public static String r(Stack reproductions)
        {
            Stack aux=new Stack();
            String text="";
            Reproductions movie;
            while(!reproductions.isEmpty())
            {
                movie=(Reproductions)reproductions.Pop();
                text=text+movie.toString()+"\n";
                aux.Push(movie);
            }
            while(!aux.isEmpty())
            {
                reproductions.Push(aux.Pop());
            }

            return text;
        }
        
         public static String c(Queue reproductions)
        {
            Queue aux=new Queue();
            String text="";
            Profile movie;
            while(!reproductions.isEmpty())
            {
                movie=(Profile)reproductions.Dequeue();
                text=text+movie.toString()+"\n";
                aux.Enqueue(movie);
            }
            while(!aux.isEmpty())
            {
                reproductions.Enqueue(aux.Dequeue());
            }

            return text;
        }
}
