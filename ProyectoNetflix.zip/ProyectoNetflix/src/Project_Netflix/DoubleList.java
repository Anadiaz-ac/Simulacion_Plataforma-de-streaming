
package Project_Netflix;
import javax.swing.*;

public class DoubleList {
    private DoubleNode first;
    private DoubleNode last;

    public DoubleNode getFirst() {
        return first;
    }
    
    public DoubleList() {
    }
    
    public boolean isEmpty(){
        
        return first==null && last==null;
    }
    
    public void AddFirst(Object data){
        if(isEmpty()){
            first =new DoubleNode(data);
            last=first;
        }
        else{
            DoubleNode n=new DoubleNode(data);
            first.setPrevious(n);
            n.setNext(first);
            first=n;
        }
    }
    
    @Override
    public String toString(){
        String text="";
        DoubleNode aux= first;
        while(aux!=null){
            text =text+ aux.getData()+"\n";
            aux=aux.getNext();
        }
        return text;
    }
    
    public void AddLast(Object data){
        if(isEmpty())
            AddFirst(data);
        else{
            DoubleNode n = new DoubleNode(data);
            last.setNext(n);
            n.setPrevious(last);
            last=n;
        } 
        
    }
    
    public int Size(){
        int counter=0;
        DoubleNode aux=last; //DoubleNode aux=next;
        while(aux!=null){
            counter++;
            aux=aux.getPrevious(); //aux=aux.getNext();
        }
       return counter; 
    }
    
    //Insertar desde una posición determinada, garantizando que posición sea valida.
    public void AddPosition(Object data, int pos){
        if(pos==1)
           AddFirst(data);
        else{
            if(pos==Size()+1)
              AddLast(data);
            else{
                DoubleNode aux=first;
                int counter=1;
                //Recorremos en la posicion en la que vamos a insertar
                while(aux!=null && counter<pos){
                    aux=aux.getNext();
                    counter++;
                }
                DoubleNode n = new DoubleNode(data);
                n.setNext(aux);
                n.setPrevious(aux.getPrevious());
                aux.getPrevious().setNext(n);
                aux.setPrevious(n);
                
                
            }
            
        }
        
    }
    
    public void Add(Object data){
        DoubleNode aux= first;
        while(aux!=null && ((String)data).compareTo((String)aux.getData())>0)
            aux=aux.getNext();
    
            if(aux!=null){
                if(aux.getPrevious()!=null){
                    DoubleNode n=new DoubleNode(data);
                    n.setNext(aux);
                    n.setPrevious(n.getPrevious());
                    aux.getPrevious().setNext(n);
                    aux.setPrevious(n);
                    
                }
                else
                    AddFirst(data);
            }
            else
                AddLast(data);
        }
    
    public boolean RemoveFirst(){
        if(!isEmpty()){
            first=first.getNext();
            if(first==null)
                last=null;
            else
                first.setPrevious(null);
            
            return true;
        }
        return false;
    }
    
    public boolean RemoveLast(){
        if(!isEmpty()){
            last=last.getNext();
            if(last==null)
                first=null;
            else
                last.setPrevious(null);
            
            return true;
        }
        return false;
    }
    
    public boolean Remove(int pos){//remover en una posicion en especifico
        if(!isEmpty()){
            if(pos==1)
                RemoveFirst();
            else{
                if(pos==Size())
                    RemoveLast();
                else{
                    int cont=1;
                    DoubleNode aux=first;
                    while(cont<pos)
                        aux=aux.getNext();
                         cont++;
                    
                    aux.getPrevious().setNext(aux.getNext());
                    aux.getNext().setPrevious(aux.getPrevious());
                }
            }
            return true;
        }
        return false;
    }
    
    public boolean Remove(String name){
        DoubleNode aux=first;
        while(aux!=null && ((String)aux.getData()).equalsIgnoreCase(name))
            aux=aux.getNext();
        
        if(aux!=null){ //Se encontro el elemento
            if(aux.getPrevious()==null)//preguntamos si es el primero 
                RemoveFirst();
            else{
                if(aux.getNext()==null)//preguntamos si es el ultimo
                    RemoveLast();
                else{
                    aux.getPrevious().setNext(aux.getNext());
                    aux.getNext().setPrevious(aux.getPrevious());
                }
            }
            return true;
        }
        return false;
    }
    
    public Accounts validate(String password, int code)
    {
        DoubleNode aux=first;
        while(aux!=null)
        {
            if(((Accounts)aux.getData()).getPassword().equals(password) && ((Accounts)aux.getData()).getCode()==code)
            {
                 return (Accounts)aux.getData();
            } 
            aux=aux.getNext();
        }
        return null;
    }
    
    public String search(String password, int code)
    {
        DoubleNode aux=first;
         while(aux!=null)
        {
            if(((Accounts)aux.getData()).getPassword().equals(password) && ((Accounts)aux.getData()).getCode()==code)
            {
                 return ((Accounts)aux.getData()).getType();
            } 
            aux=aux.getNext();
        }
         return "";
    }
    
    public int searchNprofile(String password, int code)
    {
        DoubleNode aux=first;
         while(aux!=null)
        {
            if(((Accounts)aux.getData()).getPassword().equals(password) && ((Accounts)aux.getData()).getCode()==code)
            {
                 return ((Accounts)aux.getData()).getNprofile();
            } 
            aux=aux.getNext();
        }
         return 0;
    }
    
      public void Decrease(String password, int code)
       {
         DoubleNode aux=first;
         
        while(aux!=null)
        {
             if(((Accounts)aux.getData()).getPassword().equals(password) && ((Accounts)aux.getData()).getCode()==code){
                
                int a=((Accounts)aux.getData()).getNprofile();
                ((Accounts)aux.getData()).setNprofile(a-1);
            }
            aux=aux.getNext();
          } 
       }
      
      public String RandomStatus()
      {
          int Status=(int)(Math.random()*3);
          if(Status==1)
          {
              return "Inactive";
          }
          else{
              if(Status==2)
              {
                  return "Suspended";
              }
              else{
                  return "Active";
              }
          }
      }
 
     public String ValidateStatus(int code, String password)
      {
         DoubleNode aux=first;        
        while(aux!=null)
        {
             if(((Accounts)aux.getData()).getPassword().equals(password) && ((Accounts)aux.getData()).getCode()==code){
                
                return ((Accounts)aux.getData()).getStatus();
            }
            aux=aux.getNext();
          } 
          return "";
      }
    
    public void ChangeStatus(int code, String password)
    {
       DoubleNode aux=first;        
        while(aux!=null)
        {
             if(((Accounts)aux.getData()).getPassword().equals(password) && ((Accounts)aux.getData()).getCode()==code){
                
                 String a=RandomStatus();
                ((Accounts)aux.getData()).setStatus(a);
            }
            aux=aux.getNext();
          } 
    }
    
    public String ShowName(int code, String password)
    {
        
       DoubleNode aux=first;        
        while(aux!=null)
        {
             if(((Accounts)aux.getData()).getPassword().equals(password) && ((Accounts)aux.getData()).getCode()==code){
                
                 
                 return ((Accounts)aux.getData()).getHeadline();
               
            }
            aux=aux.getNext();
          } 
        return "";
    }
    
    public DoubleList lottery()
    {
         DoubleNode aux=first;
         DoubleList l=new DoubleList();
         while(aux!=null)
         {
             if(((Accounts)aux.getData()).getStatus().equalsIgnoreCase("Inactive") || ((Accounts)aux.getData()).getStatus().equalsIgnoreCase("Suspended"))
             {
                 l.AddLast(aux.getData());
             }
             aux=aux.getNext();
         }
         
         return l;
    }
    
    public Double TotalRaised() //total recaudado
    {
        
         DoubleNode aux=first;
         double total=0;
         while(aux!=null)
         {
             if(((Accounts)aux.getData()).getStatus().equalsIgnoreCase("Active"))
             {
                 if(((Accounts)aux.getData()).getType().equalsIgnoreCase("Basic"))
                 {
                     total+=21900;
                 }
                 else{
                      if(((Accounts)aux.getData()).getType().equalsIgnoreCase("Plus"))
                      {
                           total+=31900;
                      }
                      else{
                            total+=38900;
                      }
                 }
             }
          
             aux=aux.getNext();
         }
         
         return total;               
    }
    
    
    public String AvailableProfiles()
    {
         DoubleNode aux=first;
         String text="";
         while(aux!=null)
         {
             if(((Accounts)aux.getData()).getNprofile()!=0)
             {
                 text+="Username: "+((Accounts)aux.getData()).getHeadline()+"   Available Profiles: "+((Accounts)aux.getData()).getNprofile()+"\n";
             }
             aux=aux.getNext();
          }
         return text;
    }
    
    public void porcentage()
    {
        double basic=0, plus=0, premium=0, total=0;
        double ba=0, pl=0, pr=0;
        DoubleNode aux=first;
        while(aux!=null)
        { 
            if(((Accounts)aux.getData()).getType().equalsIgnoreCase("Basic"))
            {
                basic++;
            }
            else{
                if(((Accounts)aux.getData()).getType().equalsIgnoreCase("Plus"))
                {
                    plus++;
                }
                else{
                    premium++;
                }
            }
            
            aux=aux.getNext();
        }
        
        total=basic+plus+premium;
        ba=(basic/total)*100;
        pl=(plus/total)*100;
        pr=(premium/total)*100;
        
        JOptionPane.showMessageDialog(null, "The percentage of accounts is\n Active: "+ba+" %\nInactive: "+pl+"%\n Suspended: "+pr+"%");
  
    }
    
    public void ChangeAllStatus()
    {
        DoubleNode aux=first;
        while(aux!=null)
        {         
             String a=RandomStatus();
            ((Accounts)aux.getData()).setStatus(a);
             aux=aux.getNext();
        }       
    }
    
    public String Useprofile(String password, int code)
    {
         int cont=0;
         String text="";
         String use;
         Queue auxq=new Queue();
         Stack auxp=new Stack();
         DoubleNode aux=first;        
        while(aux!=null)
        {
             if(((Accounts)aux.getData()).getPassword().equals(password) && ((Accounts)aux.getData()).getCode()==code)
             {               
                   Accounts ac=((Accounts)aux.getData());
                   
                   while(!ac.getProfile().isEmpty())
                   {
                       Profile P=(Profile)ac.getProfile().Dequeue();
                       
                       while(!P.getReproductions().isEmpty())
                       {
                          Reproductions R=(Reproductions)P.getReproductions().Pop();
                          cont++;
                          auxp.Push(R);
                       }
                       while(!auxp.isEmpty())
                       {
                           P.getReproductions().Push(auxp.Pop());
                       }

                       if(cont<=10)
                       {
                          use=" Under"; 
                       }
                       else{
                           if(cont>10 && cont<=50)
                           {
                               use=" Medium";
                           }
                           else{
                               use=" High";
                           }
                       }
                   
                       text+="Name profile: "+P.getName()+"  Use: "+use+"\n";
                       cont=0;
                       auxq.Enqueue(P);
                  }
                    while(!auxq.isEmpty())
                    {
                        ac.getProfile().Enqueue(auxq.Dequeue());
                    }
               }
                  aux=aux.getNext();
            }
              return text;
          }
    
    public TertiaryTree Recorder(){
        TertiaryTree br=new TertiaryTree();
        DoubleNode aux=first;
        
        while(aux!=null){
            
            
            if(((Accounts)aux.getData()).getStatus().equalsIgnoreCase("Suspended") || ((Accounts)aux.getData()).getStatus().equalsIgnoreCase("Inactive")){
              br.Add((Accounts)aux.getData(),br.getRoot());
              
            }
            aux=aux.getNext();
        }
      return br;  
    }
    
    
 }

