
package Project_Netflix;

import java.io.*;
public class file {
    
    private File F;
    private FileReader FR;
    private FileWriter FW;
    private BufferedReader BR;
    private BufferedWriter BW;

       public void writelist(DoubleList list)
    {
        
         DoubleNode aux = list.getFirst();
          int Val;
          int contP;
          int contS;
          int contO;
        
        try{
        
            while(aux!=null)
            {
                Accounts p = (Accounts)aux.getData();
                contP=Nviews("Movie", p);
                contS=Nviews("Series", p);
                contO=Nviews("Other", p);
                
               if(p.getType().equalsIgnoreCase("Basic")){
                    Val=21900;
                }else{
                    if(p.getType().equalsIgnoreCase("Plus")){
                       Val=31900;
                    }else{
                         Val=38900;   
                       }
                     }

                F = new File(p.getHeadline() + ".txt");
                FW = new FileWriter(F);            
                BW = new BufferedWriter(FW);
               
                BW.write("Mr "+p.getHeadline()+"\nYou have enjoyed "+contP+" Movies, "+contS+" Series and  "+contO+" Other reproductions.\n"
                       + "Don't forget to make your payment worth $"+Val);
                    
                aux = aux.getNext();
                BW.close();
                 Val=0;
                 contP=0;
                 contS=0;
                 contO=0;
            }

        }catch(IOException e)
        {
            e.printStackTrace();
        }
    }
            
    public int Nviews(String type, Accounts aux)
    {
         Queue auxQueue=new Queue();
         Stack auxStack=new Stack();
         int cont=0;
         if(aux!=null)
         {
             while(!aux.getProfile().isEmpty())
             {
                 Profile P=(Profile)aux.getProfile().Dequeue();
                 auxQueue.Enqueue(P);
                 while(!P.getReproductions().isEmpty())
                 {
                    Reproductions R=(Reproductions)P.getReproductions().Pop();
                    auxStack.Push(R);
                    if(R.getType().equalsIgnoreCase(type))
                    {
                        cont++;
                    }
                 }
                 while(!auxStack.isEmpty())
                 {
                     P.getReproductions().Push(auxStack.Pop());
                 } 
             }
             while(!auxQueue.isEmpty())
             {
                 aux.getProfile().Enqueue(auxQueue.Dequeue());
             }
         }
         return cont;
    }
}
    
