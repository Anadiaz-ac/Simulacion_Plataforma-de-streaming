
package Project_Netflix;

public class Reproductions {
    private String type;
    private String title;
    private String gender;
    private String duration;
    private int year;

    public Reproductions(String type, String title, String gender, String duration, int year) {
        this.type = type;
        this.title = title;
        this.gender = gender;
        this.duration = duration;
        this.year = year;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getGender() {
        return gender;
    }

    public void setGender(String gender) {
        this.gender = gender;
    }

    public String getDuration() {
        return duration;
    }

    public void setDuration(String duration) {
        this.duration = duration;
    }

    public int getYear() {
        return year;
    }

    public void setYear(int year) {
        this.year = year;
    }

    @Override
    public String toString() {
        return  "  Type: " + type + "  Title: " + title + "  Gender: " 
                + gender + "  Duration: " + duration + "  Year: " + year;
    }
    
    
}
