
package Project_Netflix;

import javax.swing.*;
public class Main {

    static Stack auxxs=new Stack();
    
    public static void main(String[] args) {
        
        TertiaryTree br= new TertiaryTree();
        file File = new file(); 
        DoubleList accounts=new DoubleList();
        List reproduction=new List();
        String title, type, gender, duration, headline, type1, status, password, name, language, age_setting,namep="";
        int Nprofile;
        String opt;
        String Acount_type[]={"Basic","Plus","Premium"};
        
        String Type_reproduction[]={"Movie","Series","Other"};
        
        String menu[]={"Register playback","Print playback","Register account","Print Accounts","Register profile","Print profile", "See playback", "Charge account", 
            "Top 10", "Make a giveaway", "Delete profile" , "Update account statement","Suspended and inactive accounts",
            "Porcentage of accounts","Total money active accounts","Users with available profiles","Use of each profile","Exit"};

        do{
            opt=(String)JOptionPane.showInputDialog(null,"Selected option","Main menu",
                    1, null, menu, menu[0]);
            
        switch(opt)
        {
            case "Register playback":
             type=(String)JOptionPane.showInputDialog(null,"Enter the type of reproduction","MENU",1,null, Type_reproduction,Type_reproduction[0]);
             title=JOptionPane.showInputDialog("Enter the title");
             gender=JOptionPane.showInputDialog("Enter the gender");
             duration=JOptionPane.showInputDialog("Enter duration");
             int year=Integer.parseInt(JOptionPane.showInputDialog("Enter year"));
             reproduction.Add_year(new Reproductions(type,title,gender,duration,year)); 
             JOptionPane.showMessageDialog(null, "Save playback");  
             break;

            case "Print playback":
                JOptionPane.showMessageDialog(null, "Playbacks: \n"+reproduction.toString());
                break;
                
            case "Register account":                    
             Queue q=new Queue();
             
            int code=Integer.parseInt(JOptionPane.showInputDialog("Enter code"));
                headline=JOptionPane.showInputDialog("Enter the headline");
                type1=(String)JOptionPane.showInputDialog(null,"Enter the type of account","MENU",1,null,Acount_type,Acount_type[0]);
                status="Active";
                password=JOptionPane.showInputDialog("Enter the password");
               if(type1.equalsIgnoreCase("Basic"))
               {
                Nprofile=2;
               }
             else{
                 if(type1.equalsIgnoreCase("Plus"))
                 { 
                     Nprofile=3;
                 }
                 else{
                     Nprofile=4;
                 }
             }
                accounts.AddFirst(new Accounts(code,headline,type1,status,password,q,Nprofile));
                JOptionPane.showMessageDialog(null, "Created account");                  
                break;
      
            case "Print Accounts":
                JOptionPane.showMessageDialog(null, "Accounts: \n"+accounts.toString());
                break;
  
            case "Register profile":
            code=Integer.parseInt(JOptionPane.showInputDialog("Enter code"));
            password=JOptionPane.showInputDialog("Enter the password");
            Accounts ac=accounts.validate(password, code);
            if(ac!=null)
            {  
                if(accounts.search(password, code).equalsIgnoreCase("Basic"))
                {   
                  if(accounts.searchNprofile(password, code)==2 || accounts.searchNprofile(password, code)==1)
                  {
                     Stack s=new Stack();
                     
                     name=JOptionPane.showInputDialog("Enter name");
                     language=JOptionPane.showInputDialog("Enter language");
                     age_setting=JOptionPane.showInputDialog("Enter age settings");
                     Profile a=new Profile(name,language,age_setting,s);
                     ac.getProfile().Enqueue(a);
                     accounts.Decrease(password,code);
                     JOptionPane.showMessageDialog(null, "Created Profile");
                  }
                  else{
                      JOptionPane.showMessageDialog(null, "The account already has the limit of profiles created");
                  }
                }

                if(accounts.search(password, code).equalsIgnoreCase("Plus"))
                {
                  if(accounts.searchNprofile(password,code)>=1 && accounts.searchNprofile(password,code)<=3)
                  {
                     Stack s=new Stack();
                     
                     name=JOptionPane.showInputDialog("Enter name");
                     language=JOptionPane.showInputDialog("Enter language");
                     age_setting=JOptionPane.showInputDialog("Enter age settings");
                     Profile a=new Profile(name,language,age_setting,s);
                     ac.getProfile().Enqueue(a);
                     accounts.Decrease(password,code);
                     JOptionPane.showMessageDialog(null, "Created Profile");
                  }
                  else{
                      JOptionPane.showMessageDialog(null, "The account already has the limit of profiles created");
                  }
                }

                 if(accounts.search(password, code).equalsIgnoreCase("Premium"))
                {
                  if(accounts.searchNprofile(password,code)>=1 && accounts.searchNprofile(password,code)<=4)
                  {
                     Stack s=new Stack();
                       
                     name=JOptionPane.showInputDialog("Enter name");
                     language=JOptionPane.showInputDialog("Enter language");
                     age_setting=JOptionPane.showInputDialog("Enter age settings");
                     Profile a=new Profile(name,language,age_setting,s);
                     ac.getProfile().Enqueue(a);
                     accounts.Decrease(password,code);
                     JOptionPane.showMessageDialog(null, "Created Profile");
                  }
                  else{
                      JOptionPane.showMessageDialog(null, "The account already has the limit of profiles created");
                  }
                }
            }
           else{
                  JOptionPane.showMessageDialog(null, "The code or password is wrong");
            }
             break;  
                
            case "Print profile":
               String text="";
                Queue aux=new Queue();
                code=Integer.parseInt(JOptionPane.showInputDialog("Enter code"));
                password=JOptionPane.showInputDialog("Enter the password");
                ac=accounts.validate(password, code);
                while(!ac.getProfile().isEmpty())
                {
                     Profile pro=(Profile)ac.getProfile().Dequeue();
                     text+=pro+"\n";
                     aux.Enqueue(pro);
                }
               while(!aux.isEmpty())
               {
                   ac.getProfile().Enqueue(aux.Dequeue());
               }
                       

                JOptionPane.showMessageDialog(null, "The profiles are: \n"+text);
                break;

            case "See playback":
               Queue auxx=new Queue();
               code=Integer.parseInt(JOptionPane.showInputDialog("Enter code"));
               password=JOptionPane.showInputDialog("Enter the password");
               ac=accounts.validate(password, code);
               Profile P;
 
               if(ac!=null)
              {

                    
               if(accounts.ValidateStatus(code,password).equalsIgnoreCase("Active"))
               {
                    name=JOptionPane.showInputDialog("Enter the name of profile");
                    while(!ac.getProfile().isEmpty())
                    {
                        P=(Profile)ac.getProfile().Dequeue();
                        if(P.getName().equalsIgnoreCase(name))
                        {
                            JOptionPane.showMessageDialog(null, "Playbacks: \n"+reproduction.toString());
                            title=JOptionPane.showInputDialog("What movie do you want to see?");
                            Reproductions R=reproduction.ReturnList(title);
                            if(R!=null){
                            P.getReproductions().Push(R);
                            JOptionPane.showMessageDialog(null, "The movie "+title+" was seen with success");
                            }else{
                               JOptionPane.showMessageDialog(null, "The movie doesn't exist"); 
                            }
                        }
                    auxx.Enqueue(P);
                        
                    }
                     while(!auxx.isEmpty())
                       ac.getProfile().Enqueue(auxx.Dequeue());
               }
               else{
                  JOptionPane.showMessageDialog(null, "Mr. user must reactivate the account or make the payment");                           
               }
               }
               else{
                   JOptionPane.showMessageDialog(null, "The code or password is wrong");
               }
                break;

             case "Charge account":
                 
                    File.writelist(accounts);
                    JOptionPane.showMessageDialog(null, "Saved File");

               
               
                break;
                
             case "Top 10":
                 
                 reproduction.PlayCounter(accounts);
                 
                 break;
                 
             case "Make a giveaway":
                 
              text="";
              
               br=accounts.Recorder();
               
               JOptionPane.showMessageDialog(null, "The winners of the giveaway are: \n"+br.leaf(br.getRoot(), text));
               
               JOptionPane.showMessageDialog(null, br.PreOrder(br.getRoot())); 
               
                break;
                  
             case "Delete profile":
               code=Integer.parseInt(JOptionPane.showInputDialog("Enter code"));
               password=JOptionPane.showInputDialog("Enter the password");
               Queue auxq=new Queue();
               ac=accounts.validate(password, code);
                 if(ac!=null){
                     namep=JOptionPane.showInputDialog("Enter the name of the profile you want to delete");
                     while(!ac.getProfile().isEmpty()){
                         
                         P=(Profile)ac.getProfile().Dequeue();
                          
                         if(!P.getName().equalsIgnoreCase(namep)){
                             
                             auxq.Enqueue(P);
                             
                         }
                         
                     }while(!auxq.isEmpty())
                         ac.getProfile().Enqueue(auxq.Dequeue());
                     
                 }
                 else{
                       JOptionPane.showMessageDialog(null, "The code or password is wrong");
                       
                         }
                 
                 
                JOptionPane.showMessageDialog(null, "The profile: "+namep+", has been successfully deleted.");
                 
                 break;
                 
                 // punto 9
             case "Update account statement":
                  accounts.ChangeAllStatus();
                  JOptionPane.showMessageDialog(null, "Account statement updated successfully");
                 break;
                 
                 // parte 10      
             case "Suspended and inactive accounts":  //a)
                JOptionPane.showMessageDialog(null, accounts.lottery()); 
                 break;
                 
             case "Porcentage of accounts":  //b)
                 accounts.porcentage();
                 break;
                 
             case "Total money active accounts":  // c)
             JOptionPane.showMessageDialog(null, "The total money raised by accounts that are active is: "+accounts.TotalRaised()+" $");
              break;
                 
             case "Users with available profiles":  //d)
                JOptionPane.showMessageDialog(null, "The accounts with available profiles are: \n"+accounts.AvailableProfiles()); 
                 break;
                 
                 
             case "Use of each profile": //e
                  code=Integer.parseInt(JOptionPane.showInputDialog("Enter code"));
                 password=JOptionPane.showInputDialog("Enter the password");
                 JOptionPane.showMessageDialog(null, accounts.Useprofile(password, code));
                 break;
               
            }
        }while(!opt.equals("Exit"));
    }
    
    
    
}
    

