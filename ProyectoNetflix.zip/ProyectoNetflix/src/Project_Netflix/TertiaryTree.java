
package Project_Netflix;


import javax.swing.JOptionPane;

public class TertiaryTree {
    private TertiaryNode root;

    public TertiaryTree() {
        root=null;
    }
    
    public boolean isEmpty()
    {
        return root == null;
    }
    
    public void Add(Accounts c, TertiaryNode aux)
    {
        
       
        if(isEmpty()){
            root = new TertiaryNode(c); 
           System.out.println("cabeza"+c);
        }else{
           double number = Math.random()*2;

            if(number>1.5)   
            {
                
                System.out.println("izquierdo: \n"+c.toString());
                
                if(aux.getLeft()==null)   //no tiene hijo
                    aux.setLeft(new TertiaryNode(c));
                else   
                    Add(c, aux.getLeft());
            }
            else{
            if(number<0.5){
                
                System.out.println("derecha: \n"+c.toString());
                
                if(aux.getRigth() == null)
                    aux.setRigth(new TertiaryNode(c));
                else
                    Add(c, aux.getRigth());
                }
                 else{
                
                System.out.println("mitad: \n"+c.toString());
                
                if(aux.getCenter()==null)
                  aux.setCenter(new TertiaryNode(c));
                else
                  Add(c, aux.getCenter()); 
                
            }
          }
        }
         
         
    }
    
    public String leaf(TertiaryNode aux, String text){
       
        if(aux!=null){
            if(aux.getLeft()==null && aux.getCenter()==null && aux.getRigth()==null){
                ((Accounts)aux.getData()).setStatus("Active");
                return " Name: "+((Accounts)aux.getData()).getHeadline()+" Code: "+((Accounts)aux.getData()).getCode()+"\n";
         
                
            }  
            
            text=text+leaf(aux.getLeft(),text);
            text=text+leaf(aux.getCenter(),text);
            text=text+leaf(aux.getRigth(),text);
            
         return text;   
        }else{
          
           return  "";
        } 
    }

    public TertiaryNode getRoot() {
        return root;
    }
    
    public String PreOrder(TertiaryNode aux)
    {
        if(aux!=null)
            return aux.getData() + "\n"+ PreOrder(aux.getLeft()) +PreOrder(aux.getCenter())+ PreOrder(aux.getRigth());
               //      raiz                     izquierdo                  derecho
        else
            return "";
    }
    
    public String InOrder(TertiaryNode aux)
    {
        if(aux!=null)
            return InOrder(aux.getLeft()) + aux.getData() + "  "+ InOrder(aux.getRigth());
               //      izquierdo                     raiz                   derecho
        else
            return "";
    }
    
    public String PostOrder(TertiaryNode aux)
    {
        if(aux!=null)
            return PostOrder(aux.getLeft()) + PostOrder(aux.getRigth())+ aux.getData() + "  ";
               //      izquierdo                     derecho                raiz
        else
            return "";
    }
    


}
