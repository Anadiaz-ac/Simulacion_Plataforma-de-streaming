
package Project_Netflix;


public class Profile {
    private String name;
    private String language;
    private String age_setting;
    private Stack reproductions;

    public Profile(String name, String language, String age_setting, Stack reproductions) {
        this.name = name;
        this.language = language;
        this.age_setting = age_setting;
        this.reproductions = reproductions;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getLanguage() {
        return language;
    }

    public void setLanguage(String language) {
        this.language = language;
    }

    public String getAge_setting() {
        return age_setting;
    }

    public void setAge_setting(String age_setting) {
        this.age_setting = age_setting;
    }

    public Stack getReproductions() {
        return reproductions;
    }

    public void setReproductions(Stack reproductions) {
        this.reproductions = reproductions;
    }

   @Override
    public String toString() {
        Stack aux=new Stack();
        String text="";
        Reproductions movie;
        while(!reproductions.isEmpty())
        {
            movie=(Reproductions)reproductions.Pop();
            text=text+movie.toString()+"\n";
            aux.Push(movie);
        }
        while(!aux.isEmpty())
        {
            reproductions.Push(aux.Pop());
        }
        return "Name: " + name + "   Language: " + language + "   Age setting: " + age_setting + "   Reproductions: \n" + text;
    }

 
    
    
}
