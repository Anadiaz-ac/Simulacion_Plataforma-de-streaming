package Project_Netflix;

import javax.swing.JOptionPane;

public class List {
    private Node first;
    
    public List()
    {
       first=null;
    }

    public Node getFirst() {
        return first;
    }
    
    public boolean isEmpty()
    {
        return first==null;
//        if(first==null)
//            return true;
//        else
//            return false;
    }
    
    //AddFirst-> que el elemento que vamos a guardar
    //queda de primero en la lista
    public void AddFirst(Object data)
    {
        if(isEmpty())
        {
            first = new Node(data);
            //first = new Node(data, null);
        }
        else
        {
//            Node n = new Node(data);
//            n.setLink(first);
            Node n = new Node(data,first);
            first=n;                     
        }
    }
    
    @Override
    public String toString()
    {
        String text = "";
        Node aux = first;
        while(aux!=null)
        {
            text = text + aux.getData() + "\n";
            aux = aux.getLink();
        }
        return text;
    }
    
    //Devuelve el ultimo nodo de la lista
    public Node Last()
    {
        Node aux = first, pre= null;
        while(aux!=null)
        {
            pre = aux;
            aux=aux.getLink();
        }
        return pre;
    }
    
    public void AddLast(Object data)
    {
        if(isEmpty())
            first = new Node(data);
        else
        {
            Node n = new Node(data);
            Node last = Last();
            last.setLink(n);
        }
    }
  public Node Previous (Object data){
      Node aux =first,pre=null;
      while(aux!=null && !aux.getData().equals(data)){
          pre=aux;
          aux=aux.getLink();
      }
      if (aux==null)
          return null;
          else
          return pre;     
  }
  public void Add(Object data , int pos){
      if(pos==1)
          AddFirst(data);
      else
          if (pos==1)
              AddFirst(data);
       else
              if(pos== size()+1)
                  AddLast(data);
      else{
          Node aux=first;
          int cont=1;
          while(cont!=pos){
              aux=aux.getLink();
              cont++;
          }
          Node p = Previous(aux.getData());
          Node n = new Node(data,aux);
          p.setLink(n);
      }
  }
  public void Add_year(Reproductions data)
    {
           if(isEmpty())
           {
               first=new Node(data); 
           }
           else{
               Node aux=first;
               while(aux!=null && data.getYear()>((Reproductions)aux.getData()).getYear())
               {
                   aux=aux.getLink();
               }
               if(aux==null)
               {
                   AddLast(data);
               }
               else{
                   Node pre=Previous(aux.getData());
                   if(pre==null)
                   {
                       AddFirst(data);
                   } 
                   else{
                       Node n=new Node(data,aux);
                       pre.setLink(n);
                       
                       }
               }
              
           }
       }
  public int size(){
      Node aux=first;
      int cont=0;
      while(aux!=null){
          cont++;
          aux=aux.getLink();
      }
      return cont;
  }
  
  public boolean RemoveFirst(){
      if(!isEmpty()){
          Node aux =first;
          first=first.getLink();
          aux=null;
          return true;
      }
      return false;
  }
  public boolean RemoveLast(){
      if (!isEmpty()){
          Node last=Last(); //deuelve el ultimo nodo de la lista 
          Node pre=Previous(last.getData()); //debuelve el que está anterior 
          if(pre!=null)
                  pre.setLink(null);
          else
              first=null;
          last=null; // no es necesario 
          return true;
      }
      return false;
  }
  public boolean Remove(int pos) //garantizando pos valida
    {
        if(!isEmpty())
        {
            if(pos==1)
                RemoveFirst();
            else
            {
                if(pos==size())
                    RemoveLast();
                else
                {
                    Node aux = first;
                    int cont = 1;
                    while(cont<pos)
                    {
                        aux = aux.getLink();
                        cont++;
                    }
                    Node pre = Previous(aux.getData());  //buscamos el anterior
                    pre.setLink(aux.getLink());
                    aux=null;  //no es necesaria                    
                }
            }
            return true;
        }
        return false;
    }
  
    public Reproductions ReturnList(String title)
    {
        Node aux=first;
        while(aux!=null)
        {
            if(((Reproductions)aux.getData()).getTitle().equalsIgnoreCase(title))
            {
                return (Reproductions)aux.getData();
            }
            aux=aux.getLink();
        }
        return null;
    }
    
    public void PlayCounter(DoubleList lista){
       int total=0;  
        Node aux=first;
        Node aux3=first;
        Accounts c;
        Queue auxq=new Queue();
        Stack auxs=new Stack();
        Profile p;
        Reproductions r;
        DoubleNode aux2;
        int v[]=new int[size()];
        String tx="", text="";
        int h=0;
        int b=0;
        
        for (int j = 0; j < size(); j++) {
            v[j]=0;
        }
        
        
        while(aux!=null){
           
            aux2=lista.getFirst();
            while(aux2!=null){
            c=(Accounts)aux2.getData();
            
        while(!c.getProfile().isEmpty()){
                p= (Profile)c.getProfile().Dequeue();
                while(!p.getReproductions().isEmpty()){
                    r=(Reproductions)p.getReproductions().Pop();
                    
                    if(((Reproductions)aux.getData()).getTitle().equalsIgnoreCase(r.getTitle()) ){
                        total++;
                   
                    }
                    
                    
                  auxs.Push(r);
                }while(!auxs.isEmpty())
                  p.getReproductions().Push(auxs.Pop());
                
                auxq.Enqueue(p);
            }while(!auxq.isEmpty())
             c.getProfile().Enqueue(auxq.Dequeue());
            aux2=aux2.getNext();
            
        }
           
                v[h]=total;
                b=v[h];
                h++;
                
           tx+="The movie is: "+((Reproductions)aux.getData()).getTitle()+" Has been seen: "+b+"\n";
           total=0;
       aux=aux.getLink();
    }
        int a;
        Reproductions l;
        aux= first;
        for (int i = 0; i < v.length-1; i++) {
            aux3=aux.getLink();
            for (int j = i+1; j <v.length; j++) {
                if(v[i]<v[j]){
                    l=(Reproductions)aux.getData();
                    aux.setData(aux3.getData());
                    aux3.setData(l);
                    a=v[i];
                    v[i]=v[j];
                    v[j]=a;
                    
                }
                aux3=aux3.getLink();
            }
            aux=aux.getLink();
        }
        aux=first;
        for (int i = 0; i < 10; i++) {
            if(aux!=null){
              text=text+aux.getData()+"\n";
               aux=aux.getLink();
            }
            
        }
         JOptionPane.showMessageDialog(null, "The number of views of each movie are: \n"+tx);
         JOptionPane.showMessageDialog(null, "The top 10 is: \n"+text);
         
        }
        
        
//     
}
